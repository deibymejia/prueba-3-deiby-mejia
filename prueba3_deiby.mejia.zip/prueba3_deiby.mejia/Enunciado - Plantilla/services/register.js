import { URL_USERS } from "./router.js";
import { URL_BASE } from "./router.js";





const urlServer="http://localhost:3000";


let formulario=document.querySelector("#registerForm");



formulario.addEventListener("subtmi", async()=>{
    await formulario(urlServer,{
        name:document.querySelector("#name").value,
        email:document.querySelector("#email").value,
        Birth:document.querySelector("#dob").value,
        contraseña:document.querySelector("#password").value
        
    });
});


formulario.addEventListener("submit", async ()=>{
   
    const input=document.querySelector("#submit").value;
    await input(urlServer,inputSearch);   
});






















/* const form =document.getElementById("registerForm");
const nombre =document.getElementById("name");

form.addEventListener("submit", ()=>{
  const info = nombre.value
  
  post(URL_USERS,{
    "name":info
  })
}) */
